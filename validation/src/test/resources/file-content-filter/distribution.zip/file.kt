class ForbiddenClass {}
